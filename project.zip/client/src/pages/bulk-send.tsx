import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Upload, Send, Loader2, CheckCircle2, AlertCircle, FileSpreadsheet } from "lucide-react";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import { apiRequest } from "@/lib/queryClient";

interface MessageTask {
  phone: string;
  message: string;
}

export default function BulkSend() {
  const [tasks, setTasks] = useState<MessageTask[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [remainingCount, setRemainingCount] = useState(0);
  const [estimatedTimeSeconds, setEstimatedTimeSeconds] = useState(0);
  const [uploadError, setUploadError] = useState<string>("");
  const [uploadSuccess, setUploadSuccess] = useState<string>("");
  const [sendError, setSendError] = useState<string>("");
  const [successCount, setSuccessCount] = useState(0);
  const [failureCount, setFailureCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sendIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isResuming = useRef(false);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const checkForSavedProgress = async () => {
    setUploadError("");
    setUploadSuccess("");
    setSendError("");
    
    try {
      const response = await fetch('/api/bulk-send/progress');
      const data = await response.json();
      
      if (data.success && data.progress) {
        const { tasks: savedTasks, currentIndex: savedIndex } = data.progress;
        
        if (savedTasks && savedTasks.length > 0 && savedIndex < savedTasks.length) {
          setTasks(savedTasks);
          setCurrentIndex(savedIndex);
          setRemainingCount(savedTasks.length - savedIndex);
          setEstimatedTimeSeconds((savedTasks.length - savedIndex) * 2.5);
          setUploadSuccess(`تم استعادة ${savedTasks.length} رسالة. سيتم الاستكمال من الرسالة رقم ${savedIndex + 1}`);
          isResuming.current = true;
        } else {
          setUploadError("لا يوجد تقدم محفوظ للاستكمال");
        }
      } else {
        setUploadError("لا يوجد تقدم محفوظ للاستكمال");
      }
    } catch (error) {
      console.error('Failed to check saved progress:', error);
      setUploadError("فشل في استرجاع التقدم المحفوظ");
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadError("");
    setUploadSuccess("");
    setSendError("");

    const isCSV = file.name.endsWith('.csv');
    const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');

    if (!isCSV && !isExcel) {
      setUploadError("الرجاء رفع ملف CSV أو Excel فقط (.csv, .xlsx, .xls)");
      return;
    }

    if (isCSV) {
      Papa.parse<string[]>(file, {
        complete: (results) => {
          try {
            const rows = results.data;
            
            if (rows.length < 2) {
              setUploadError("ملف CSV فارغ أو لا يحتوي على بيانات");
              return;
            }

            const headers = rows[0];
            const phoneIndex = headers.findIndex(h => 
              h.trim() === "رقم الهاتف" || h.toLowerCase().includes("phone")
            );
            const messageIndex = headers.findIndex(h => 
              h.trim() === "الرساله الخاصه بالرقم" || h.toLowerCase().includes("message")
            );

            if (phoneIndex === -1 || messageIndex === -1) {
              setUploadError("يجب أن يحتوي الملف على عمودين: 'رقم الهاتف' و 'الرساله الخاصه بالرقم'");
              return;
            }

            const parsedTasks: MessageTask[] = [];
            for (let i = 1; i < rows.length; i++) {
              const row = rows[i];
              if (row.length <= Math.max(phoneIndex, messageIndex)) continue;
              
              const phone = row[phoneIndex]?.trim();
              const message = row[messageIndex]?.trim();
              
              if (phone && message) {
                parsedTasks.push({ phone, message });
              }
            }

            if (parsedTasks.length === 0) {
              setUploadError("لم يتم العثور على بيانات صحيحة في الملف");
              return;
            }

            setTasks(parsedTasks);
            setRemainingCount(parsedTasks.length);
            setEstimatedTimeSeconds(parsedTasks.length * 2.5);
            setUploadSuccess(`تم تحميل ${parsedTasks.length} رسالة بنجاح من ملف CSV`);
            setCurrentIndex(0);
            setSuccessCount(0);
            setFailureCount(0);
          } catch (error) {
            setUploadError("فشل في قراءة ملف CSV");
            console.error(error);
          }
        },
        error: (error) => {
          setUploadError("خطأ في قراءة الملف: " + error.message);
        }
      });
    } else if (isExcel) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          if (rows.length < 2) {
            setUploadError("ملف Excel فارغ أو لا يحتوي على بيانات");
            return;
          }

          const headers = rows[0];
          const phoneIndex = headers.findIndex((h: any) => 
            String(h).trim() === "رقم الهاتف" || String(h).toLowerCase().includes("phone")
          );
          const messageIndex = headers.findIndex((h: any) => 
            String(h).trim() === "الرساله الخاصه بالرقم" || String(h).toLowerCase().includes("message")
          );

          if (phoneIndex === -1 || messageIndex === -1) {
            setUploadError("يجب أن يحتوي الملف على عمودين: 'رقم الهاتف' و 'الرساله الخاصه بالرقم'");
            return;
          }

          const parsedTasks: MessageTask[] = [];
          for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            if (!row || row.length <= Math.max(phoneIndex, messageIndex)) continue;
            
            const phone = String(row[phoneIndex] || '').trim();
            const message = String(row[messageIndex] || '').trim();
            
            if (phone && message) {
              parsedTasks.push({ phone, message });
            }
          }

          if (parsedTasks.length === 0) {
            setUploadError("لم يتم العثور على بيانات صحيحة في الملف");
            return;
          }

          setTasks(parsedTasks);
          setRemainingCount(parsedTasks.length);
          setEstimatedTimeSeconds(parsedTasks.length * 2.5);
          setUploadSuccess(`تم تحميل ${parsedTasks.length} رسالة بنجاح من ملف Excel`);
          setCurrentIndex(0);
          setSuccessCount(0);
          setFailureCount(0);
        } catch (error) {
          setUploadError("فشل في قراءة ملف Excel");
          console.error(error);
        }
      };
      reader.onerror = () => {
        setUploadError("خطأ في قراءة الملف");
      };
      reader.readAsBinaryString(file);
    }
  };

  const sendSingleMessage = async (phone: string, message: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/send-direct', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ number: phone, message })
      });

      const data = await response.json();
      if (!data.success) {
        setSendError(`فشل في إرسال الرسالة إلى ${phone}: ${data.error || 'خطأ غير معروف'}`);
        return false;
      }
      return true;
    } catch (error: any) {
      console.error(`Failed to send message to ${phone}:`, error);
      setSendError(`فشل الاتصال أثناء الإرسال إلى ${phone}`);
      return false;
    }
  };

  const startSending = async () => {
    if (tasks.length === 0 || isSending) return;

    try {
      const statusResponse = await fetch('/api/status');
      const statusData = await statusResponse.json();
      
      if (!statusData.ready) {
        setSendError("WhatsApp غير متصل. الرجاء التأكد من مسح QR Code أولاً من صفحة الإرسال الفردي.");
        return;
      }
    } catch (error) {
      setSendError("فشل التحقق من حالة WhatsApp. الرجاء المحاولة مرة أخرى.");
      return;
    }

    setSendError("");
    setIsSending(true);
    
    const startIndex = isResuming.current ? currentIndex : 0;
    isResuming.current = false;
    
    setCurrentIndex(startIndex);
    setRemainingCount(tasks.length - startIndex);
    setEstimatedTimeSeconds((tasks.length - startIndex) * 2.5);
    setSuccessCount(0);
    setFailureCount(0);

    try {
      await apiRequest('POST', '/api/bulk-send/start', { tasks });
    } catch (error) {
      console.error('Failed to start bulk send:', error);
    }

    let index = startIndex;
    let successTotal = 0;
    let failureTotal = 0;

    const sendNext = async () => {
      if (index >= tasks.length) {
        stopSending();
        setUploadSuccess(`اكتمل الإرسال! نجح: ${successTotal}, فشل: ${failureTotal}`);
        
        try {
          await apiRequest('POST', '/api/bulk-send/complete');
        } catch (error) {
          console.error('Failed to complete bulk send:', error);
        }
        return;
      }

      const task = tasks[index];
      const success = await sendSingleMessage(task.phone, task.message);
      
      if (success) {
        successTotal++;
        setSuccessCount(successTotal);
      } else {
        failureTotal++;
        setFailureCount(failureTotal);
      }

      index++;
      setCurrentIndex(index);
      setRemainingCount(tasks.length - index);
      setEstimatedTimeSeconds((tasks.length - index) * 2.5);

      try {
        await apiRequest('POST', '/api/bulk-send/update-progress', { currentIndex: index });
      } catch (error) {
        console.error('Failed to update progress:', error);
      }

      if (index < tasks.length) {
        sendIntervalRef.current = setTimeout(sendNext, 2500);
      }
    };

    sendNext();
  };

  const stopSending = () => {
    if (sendIntervalRef.current) {
      clearTimeout(sendIntervalRef.current);
      sendIntervalRef.current = null;
    }
    setIsSending(false);
  };

  useEffect(() => {
    return () => {
      if (sendIntervalRef.current) {
        clearTimeout(sendIntervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isSending && estimatedTimeSeconds > 0) {
      const timer = setInterval(() => {
        setEstimatedTimeSeconds(prev => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isSending, estimatedTimeSeconds]);

  const progress = tasks.length > 0 ? ((currentIndex / tasks.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">إرسال رسائل WhatsApp بالجملة</CardTitle>
            <CardDescription>
              ارفع ملف Excel أو CSV يحتوي على أرقام الهواتف والرسائل للإرسال عبر WhatsApp API
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              {tasks.length === 0 && (
                <div className="flex justify-end">
                  <Button
                    onClick={checkForSavedProgress}
                    variant="outline"
                    size="sm"
                    disabled={isSending}
                    data-testid="button-restore-progress"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    استعادة التقدم المحفوظ
                  </Button>
                </div>
              )}
              
              <div>
                <Label htmlFor="csv-upload">رفع ملف Excel أو CSV</Label>
                <div className="mt-2">
                  <input
                    id="csv-upload"
                    ref={fileInputRef}
                    type="file"
                    accept="text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,.csv,.xlsx,.xls"
                    onChange={handleFileUpload}
                    disabled={isSending}
                    data-testid="input-csv-upload"
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer"
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  يمكنك رفع ملف Excel (.xlsx, .xls) أو CSV. يجب أن يحتوي الملف على عمودين: "رقم الهاتف" و "الرساله الخاصه بالرقم"
                </p>
              </div>

              {uploadError && (
                <Alert variant="destructive" data-testid="alert-upload-error">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{uploadError}</AlertDescription>
                </Alert>
              )}

              {sendError && (
                <Alert variant="destructive" data-testid="alert-send-error">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{sendError}</AlertDescription>
                </Alert>
              )}

              {uploadSuccess && (
                <Alert data-testid="alert-upload-success">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>{uploadSuccess}</AlertDescription>
                </Alert>
              )}

              {tasks.length > 0 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>إجمالي الرسائل</CardDescription>
                        <CardTitle className="text-3xl" data-testid="text-total-messages">
                          {tasks.length}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>المتبقي</CardDescription>
                        <CardTitle className="text-3xl" data-testid="text-remaining-messages">
                          {remainingCount}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>نجح</CardDescription>
                        <CardTitle className="text-3xl text-green-600" data-testid="text-success-count">
                          {successCount}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardDescription>فشل</CardDescription>
                        <CardTitle className="text-3xl text-red-600" data-testid="text-failure-count">
                          {failureCount}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>الوقت المتبقي المتوقع</CardDescription>
                      <CardTitle className="text-4xl" data-testid="text-estimated-time">
                        {formatTime(estimatedTimeSeconds)}
                      </CardTitle>
                    </CardHeader>
                  </Card>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>التقدم</span>
                      <span data-testid="text-progress-percentage">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} data-testid="progress-bar" />
                  </div>

                  <div className="flex gap-3">
                    {!isSending ? (
                      <Button
                        onClick={startSending}
                        className="flex-1"
                        size="lg"
                        data-testid="button-start-sending"
                      >
                        <Send className="mr-2 h-5 w-5" />
                        {currentIndex > 0 && currentIndex < tasks.length ? 'استكمال الإرسال' : 'بدء الإرسال'}
                      </Button>
                    ) : (
                      <Button
                        onClick={stopSending}
                        variant="destructive"
                        className="flex-1"
                        size="lg"
                        data-testid="button-stop-sending"
                      >
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        إيقاف الإرسال
                      </Button>
                    )}
                    <Button
                      onClick={async () => {
                        setTasks([]);
                        setCurrentIndex(0);
                        setRemainingCount(0);
                        setEstimatedTimeSeconds(0);
                        setUploadSuccess("");
                        setSuccessCount(0);
                        setFailureCount(0);
                        if (fileInputRef.current) {
                          fileInputRef.current.value = "";
                        }
                        try {
                          await apiRequest('POST', '/api/bulk-send/complete');
                        } catch (error) {
                          console.error('Failed to clear progress:', error);
                        }
                      }}
                      variant="outline"
                      disabled={isSending}
                      data-testid="button-clear"
                    >
                      مسح
                    </Button>
                  </div>
                </div>
              )}
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                مثال على صيغة الملف
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium mb-2">Excel أو CSV:</p>
                  <div className="bg-muted rounded-md p-4 font-mono text-sm overflow-x-auto">
                    <pre>
{`رقم الهاتف           | الرساله الخاصه بالرقم
------------------------------------------
201234567890        | مرحبا! هذه رسالة تجريبية
201987654321        | شكرا لك على اهتمامك
201555555555        | تحديث مهم لك`}
                    </pre>
                  </div>
                </div>
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>ملاحظات مهمة:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>يجب أن يحتوي الملف على عمودين بالضبط: "رقم الهاتف" و "الرساله الخاصه بالرقم"</li>
                      <li>يجب أن يكون رقم الهاتف بصيغة دولية (مثال: 201234567890)</li>
                      <li>تأكد من أن WhatsApp متصل من صفحة الإرسال الفردي قبل البدء</li>
                      <li>يتم إرسال رسالة كل 2.5 ثانية لتجنب الحظر</li>
                      <li>سيتم حفظ التقدم تلقائياً ويمكن الاستكمال عند إعادة التشغيل</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
